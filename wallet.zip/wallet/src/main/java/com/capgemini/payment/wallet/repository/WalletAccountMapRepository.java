package com.capgemini.payment.wallet.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.payment.wallet.model.WalletUserMapping;

@Repository("walletAccountMapRepository")
public interface WalletAccountMapRepository extends JpaRepository<WalletUserMapping, Integer>{

}
