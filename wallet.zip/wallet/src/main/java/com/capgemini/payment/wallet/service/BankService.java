package com.capgemini.payment.wallet.service;

import com.capgemini.payment.wallet.model.Bank;

public interface BankService {
	
	public boolean addBankAccount(Bank bank);
	
	public Bank findBankDetails(int walletId);
	
//	public List<Bank> viewAllBankAccounts();
//	
//	public boolean deleteBankAccount(BigInteger accountNumber);

}
