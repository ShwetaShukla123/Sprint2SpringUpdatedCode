package com.capgemini.payment.wallet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.payment.wallet.model.BankWallet;

public interface BankWalletRepository extends JpaRepository<BankWallet, Integer>{
	
	
}
