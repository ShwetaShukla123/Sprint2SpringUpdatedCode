package com.capgemini.payment.wallet.service;

import java.util.List;

import com.capgemini.payment.wallet.model.BillPayment;

public interface IBillService {
	
	public List<BillPayment> getAllBillPayment(int customerId);
	public boolean payDthBill(BillPayment payment);

}
