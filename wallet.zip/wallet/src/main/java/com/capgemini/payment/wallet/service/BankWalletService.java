package com.capgemini.payment.wallet.service;

import java.math.BigInteger;

import com.capgemini.payment.wallet.model.BankWallet;

public interface BankWalletService {
	
	public boolean addBankToWallet(BankWallet bankWallet);

	public boolean findBankToWallet(int walletAccountId);
	
	//public boolean deleteBanktoWallet(int wallletId);
	
	public BigInteger findBankAccountId(int wallletId);
	
}
