package com.capgemini.payment.wallet.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="bank")
@Table
public class Bank {
	
	@Id
	@Column(name = "accountNo")
	private BigInteger accountNo;
	
	@Column(name = "holderName")
	private String holderName;
	
	@Column(name = "ifscCode")
	private String ifscCode;
	
	@Column(name = "bankName")
	private String bankName;
	
	public BigInteger getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(BigInteger accountNo) {
		this.accountNo = accountNo;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public Bank() {
		super();
	}
	public Bank(BigInteger accountNo, String holderName, String ifscCode, String bankName) {
		super();
		this.accountNo = accountNo;
		this.holderName = holderName;
		this.ifscCode = ifscCode;
		this.bankName = bankName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


}
