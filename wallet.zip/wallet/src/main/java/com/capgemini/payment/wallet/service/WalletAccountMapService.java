package com.capgemini.payment.wallet.service;

import com.capgemini.payment.wallet.model.WalletUserMapping;

public interface WalletAccountMapService {
	
	public boolean setwalletMapping(WalletUserMapping walletUserMapping);
	
	public int getWalletAccountId(int userId);

}
