package com.capgemini.payment.wallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.payment.wallet.model.WalletUserMapping;
import com.capgemini.payment.wallet.repository.WalletAccountMapRepository;

@Service
public class WalletAccountMapServiceImpl implements WalletAccountMapService{
	
	@Autowired
	WalletAccountMapRepository walletAccountMapRepository;
	
	public boolean setwalletMapping(WalletUserMapping walletUserMapping) {
		boolean flag = false;
		try {
			walletAccountMapRepository.save(walletUserMapping);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	public int getWalletAccountId(int userId) {
		int walletAccountId = 0;
		try {
			walletAccountId = walletAccountMapRepository.findById(userId).get().getWalletAccountId();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return walletAccountId;
	}
}
