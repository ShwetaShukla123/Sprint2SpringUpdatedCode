package com.capgemini.payment.wallet.model;

public enum Status {
	
		ACTIVE, INACTIVE;
	
}
