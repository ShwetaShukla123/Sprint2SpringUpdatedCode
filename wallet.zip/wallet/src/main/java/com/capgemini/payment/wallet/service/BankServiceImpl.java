package com.capgemini.payment.wallet.service;

import java.math.BigInteger;

//import java.math.BigInteger;
//import java.util.ArrayList;
//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.payment.wallet.model.Bank;
import com.capgemini.payment.wallet.repository.BankRepository;

@Service
public class BankServiceImpl implements BankService{
	
	@Autowired
	BankRepository bankRepository;
	
	@Autowired
	BankWalletService bankWalletService;

	@Override
	public boolean addBankAccount(Bank bank) {
		boolean addFlag=false;
		try {
			bankRepository.save(bank);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return addFlag;
	}
	
	@Override
	public Bank findBankDetails(int walletId) {
		Bank bankObj = null;
		try {
			BigInteger bankId = bankWalletService.findBankAccountId(walletId);
			bankObj = bankRepository.findById(bankId).get();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return bankObj;
	}
	
	
//	@Override
//	public List<Bank> viewAllBankAccounts() {
//		List<Bank> allAccountDetails=new ArrayList<Bank>();
//		try {
//				allAccountDetails=bankRepository.findAll();
//			}
//		catch(Exception e) 
//			{
//				e.printStackTrace();//chill karo ho jayega
//			}
//		return allAccountDetails;
//	} 
//	
//	@Override
//	public boolean deleteBankAccount(BigInteger accountNumber) {
//		boolean deleteFlag=false;
//		try {
//			bankRepository.deleteAccountByNo(accountNumber);
//			}
//		catch(Exception e)
//			{
//				e.printStackTrace();
//				deleteFlag=true;
//			}
//		return deleteFlag;
//	}


}
