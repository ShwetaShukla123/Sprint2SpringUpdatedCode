package com.capgemini.payment.wallet.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "bankWallet")
@Table
public class BankWallet {
	
	public BankWallet() {
		super();
	}

	public BankWallet(BigInteger bankAccountId, int walletAccountId) {
		super();
		this.bankAccountId = bankAccountId;
		this.walletAccountId = walletAccountId;
	}
	@Id
	@Column(name = "walletAccountId")
	int walletAccountId;


	@Column(name = "bankAccountId")
	BigInteger bankAccountId;
	
	
	public BigInteger getBankAccountId() {
		return bankAccountId;
	}

	public void setBankAccountId(BigInteger bankAccountId) {
		this.bankAccountId = bankAccountId;
	}

	public int getWalletAccountId() {
		return walletAccountId;
	}

	public void setWalletAccountId(int walletAccountId) {
		this.walletAccountId = walletAccountId;
	}
	
}
