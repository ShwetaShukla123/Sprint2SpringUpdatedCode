package com.capgemini.payment.wallet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "WalletUserMapping")
public class WalletUserMapping {
	
	@Id
	private int userId;
	@Column
	private int walletAccountId;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getWalletAccountId() {
		return walletAccountId;
	}
	public void setWalletAccountId(int walletAccountId) {
		this.walletAccountId = walletAccountId;
	}
	public WalletUserMapping(int userId, int walletAccountId) {
		super();
		this.userId = userId;
		this.walletAccountId = walletAccountId;
	}
	public WalletUserMapping() {
		super();
	}
	
}
