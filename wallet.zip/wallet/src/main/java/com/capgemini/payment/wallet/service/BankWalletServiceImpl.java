package com.capgemini.payment.wallet.service;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.payment.wallet.model.BankWallet;
import com.capgemini.payment.wallet.repository.BankWalletRepository;

@Service
public class BankWalletServiceImpl implements BankWalletService{
	
	@Autowired
	BankWalletRepository bankWalletRepository;

	@Override
	public boolean addBankToWallet(BankWallet bankWallet) {
		boolean flag = false;
		try {
			bankWalletRepository.save(bankWallet);
			flag = true;
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	public boolean findBankToWallet(int walletAccountId) {
		boolean flag = false;
		try {
			flag = bankWalletRepository.existsById(walletAccountId);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
//	public boolean deleteBanktoWallet(int wallletId) 
//	{
//		boolean flag = false;
//		try {
//			bankWalletRepository.deleteById(wallletId);
//			flag = true;
//		}
//		catch(Exception ex) {
//			ex.printStackTrace();
//		}
//		return flag;
//	}
	
	@Override
	public BigInteger findBankAccountId(int wallletId) {
		BigInteger bankId = null;
		try {
			bankId = bankWalletRepository.findById(wallletId).get().getBankAccountId();
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return bankId;
	}
	
	
}
