package com.capgemini.payment.wallet.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.payment.wallet.model.BillPayment;
import com.capgemini.payment.wallet.service.IBillService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping()
public class BillController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IBillService billService;
	
	@PostMapping("/pay")
	public String saveCustomer(@RequestBody BillPayment billpayment)
	{
		try {
			billService.payDthBill(billpayment);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "Bill Paid";
	}
	
	@GetMapping("bills/{customerId}")
	public List<BillPayment> bills(@PathVariable int customerId)
	{
		return billService.getAllBillPayment(customerId);
	}

}
