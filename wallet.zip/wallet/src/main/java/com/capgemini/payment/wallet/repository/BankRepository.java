package com.capgemini.payment.wallet.repository;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;

import com.capgemini.payment.wallet.model.Bank;

@Repository("bankRepository")
public interface BankRepository extends JpaRepository<Bank, BigInteger>{
	

}
