package com.capgemini.payment.wallet.controller;

//import java.math.BigInteger;
//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.payment.wallet.model.Bank;
import com.capgemini.payment.wallet.model.BankWallet;
import com.capgemini.payment.wallet.service.BankService;
import com.capgemini.payment.wallet.service.BankWalletService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping()
public class BankController {
	
	@Autowired
	BankService bankService;
	
	@Autowired 
	BankWalletService bankWalletService;
	
	@PostMapping("/add")
	public boolean addAccount(@RequestBody Bank bank) 
	{
		boolean flag = false;
		try {
			flag = bankService.addBankAccount(bank);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	@PostMapping("/addBankWallet")
	public boolean addBankWallet(@RequestBody BankWallet bankWallet) 
	{
		boolean flag = false;
		try {
			flag = bankWalletService.addBankToWallet(bankWallet);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	@GetMapping("/check/{walletAccountId}")
	public boolean checkAccount(@PathVariable int walletAccountId) 
	{
		boolean flag = false;
		try {
			flag = bankWalletService.findBankToWallet(walletAccountId);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	@GetMapping("/findBankDetails/{walletAccountId}")
	public Bank findBankDetails(@PathVariable int walletAccountId) {
		Bank bankObj = null;
		try {
			bankObj = bankService.findBankDetails(walletAccountId);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return bankObj;
	}
//	
//	@RequestMapping("/listBank")//maps web requests
//	public List<Bank> viewAllAccount(Model modelObj)
//	{
//		 return bankService.viewAllBankAccounts();
//	}
//	
//	@GetMapping("/deleteBankWallet/{wallletId}")
//	public boolean deleteBanktoWallet(@PathVariable int wallletId) 
//	{
//		boolean flag = false;
//		try {
//			flag = bankWalletService.deleteBanktoWallet(wallletId);
//		}
//		catch(Exception ex) {
//			ex.printStackTrace();
//		}
//		return flag;
//	}
//	
//	@GetMapping("/deleteBank/{id}")
//	public void deleteAccount(@PathVariable(value = "id")  BigInteger id){
//		bankService.deleteBankAccount(id);
//	}
}
