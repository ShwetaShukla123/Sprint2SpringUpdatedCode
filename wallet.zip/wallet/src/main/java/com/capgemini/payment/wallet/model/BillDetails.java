package com.capgemini.payment.wallet.model;
import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bill_details")
public class BillDetails {
@Id
private BigInteger billNo;
private String holderName;
private String connectionCode;
private Double billAmount;


public BillDetails(BigInteger billNo, String holderName, String connectionCode, Double billAmount) {
	super();
	this.billNo = billNo;
	this.holderName = holderName;
	this.connectionCode = connectionCode;
	this.billAmount = billAmount;
}


public BigInteger getBillNo() {
	return billNo;
}


public void setBillNo(BigInteger billNo) {
	this.billNo = billNo;
}


public String getHolderName() {
	return holderName;
}


public void setHolderName(String holderName) {
	this.holderName = holderName;
}


public String getConnectionCode() {
	return connectionCode;
}


public void setConnectionCode(String connectionCode) {
	this.connectionCode = connectionCode;
}


public Double getBillAmount() {
	return billAmount;
}


public void setBillAmount(Double billAmount) {
	this.billAmount = billAmount;
}


public BillDetails() {}
}
