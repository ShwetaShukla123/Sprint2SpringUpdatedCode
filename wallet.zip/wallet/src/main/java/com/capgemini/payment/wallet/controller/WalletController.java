package com.capgemini.payment.wallet.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.payment.wallet.model.Status;
import com.capgemini.payment.wallet.model.WalletAccount;
import com.capgemini.payment.wallet.model.WalletUserMapping;
import com.capgemini.payment.wallet.service.WalletAccountMapService;
import com.capgemini.payment.wallet.service.WalletAccountService;

@RestController
@CrossOrigin(origins="http://localhost:4200") 
public class WalletController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
    private WalletAccountService walletAccountService;
	
	@Autowired 
	private WalletAccountMapService walletAccountMapService;
	
	@RequestMapping(method = RequestMethod.GET,value = "/create/{userId}")
	public ResponseEntity<Integer> saveWalletUser(@PathVariable int userId) {
		WalletAccount account = new WalletAccount();
		account.setStatus(Status.ACTIVE);
		account.setAccountBalance(0);
		
		try {
		account = walletAccountService.createWalletAccount(account);
		WalletUserMapping mapping = new WalletUserMapping();
		mapping.setUserId(userId);
		mapping.setWalletAccountId(account.getAccountId());
		walletAccountMapService.setwalletMapping(mapping);
		}catch (Exception ex) {
			return new ResponseEntity<Integer>(0, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Integer>(account.getAccountId(), HttpStatus.CREATED);

	}
	
	@GetMapping("/getWalletAccountId/{userId}")
	public int getWalletAccountId(@PathVariable int userId) {
		int walletAccountId = 0;
		try {
			walletAccountId = walletAccountMapService.getWalletAccountId(userId);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return walletAccountId;
	}
	
	@GetMapping("/addMoney/{accountId}/{amount}")
	public double addMoney(@PathVariable int accountId, @PathVariable double amount) {
		double finalBalance = 0;
		try {
			WalletAccount account = walletAccountService.getAccountInfo(accountId);
			double prevBalance = account.getAccountBalance();
			finalBalance  = prevBalance + amount;
			account.setAccountBalance(finalBalance);
			finalBalance = walletAccountService.updateBalance(account);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return finalBalance;
	}
	
	@GetMapping("/getAccountInfo/{accountId}")
	public WalletAccount getAccountInfo(@PathVariable int accountId){
		WalletAccount accountDetails = null;
		try {
			accountDetails = walletAccountService.getAccountInfo(accountId);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return accountDetails;
	}
	
	@GetMapping("/getBalance/{accountId}")
	public double getBalance(@PathVariable int accountId) {
		double balance = 0;
		try {
			balance = walletAccountService.getBalance(accountId);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return balance;
	}
	
}